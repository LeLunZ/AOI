#include "spiel.h"


int guess(int N, int Q)
{
	return 0;
}
