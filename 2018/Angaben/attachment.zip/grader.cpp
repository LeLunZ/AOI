#include "spiel.h"
#include <cstdio>
#include <cstdlib>
#include <algorithm>

static int n,q,l,x,cnt;

bool ask(const std::vector<int> &s)
{
	if (cnt==q)
	{
		printf("Zu viele Fragen\n");
		exit(0);
	}
	cnt++;
	bool has=std::find(s.begin(),s.end(),x)!=s.end();
	return cnt==l?!has:has;
}

int main()
{
	scanf("%d %d %d %d",&n,&q,&x,&l);
	int res=guess(n,q);
	if (res==x)
		printf("Richtig, %d Fragen\n",cnt);
	else
		printf("Falsch, %d - %d\n",res,x);
	return 0;
}
