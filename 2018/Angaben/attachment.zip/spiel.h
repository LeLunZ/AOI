#ifndef __SPIEL

#include <vector>

int guess(int,int);
bool ask(const std::vector<int> &);

#endif
